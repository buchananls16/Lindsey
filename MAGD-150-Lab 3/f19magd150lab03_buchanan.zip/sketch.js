function setup() {
  // put setup code here
  createCanvas(500, 500);
  background(100, 255, 55)
}

function draw() {
  // put drawing code here
}